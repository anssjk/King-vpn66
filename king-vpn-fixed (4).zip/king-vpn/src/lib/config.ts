/**
 * The panel connection, entered by the user on first launch.
 *
 * Nothing here is baked in at build time. The same APK works for every user: whoever
 * installs it types their own panel address and token on the device, and both are kept
 * in AsyncStorage. That also means a rebuild is never needed when the panel moves to a
 * new domain or a token is rotated.
 */

export type PanelConfig = {
  /** Panel base URL: scheme present, no trailing slash. */
  baseUrl: string;
  /** The token the panel issued for this user. */
  token: string;
};

export const EMPTY_PANEL: PanelConfig = { baseUrl: '', token: '' };

const SCHEME = /^https?:\/\//i;
// A hostname of letters, digits, dots, dashes or underscores, an optional port, and an
// optional path. Deliberately strict: a typo must be caught here, not at request time.
const URL_RE = /^https?:\/\/[a-z0-9._-]+(:\d+)?(\/[^\s]*)?$/i;

/** Trim, add https:// when the scheme is missing, and drop trailing slashes. */
export function normalizeBaseUrl(input: string): string {
  let value = input.trim();
  if (!value) return '';
  if (!SCHEME.test(value)) value = `https://${value}`;
  return value.replace(/\/+$/, '');
}

/** True when `input` is a usable http(s) address. */
export function isValidBaseUrl(input: string): boolean {
  const value = normalizeBaseUrl(input);
  return value.length > 0 && URL_RE.test(value);
}

/** True when `input` looks like a token: at least 6 characters, no whitespace. */
export function isValidToken(input: string): boolean {
  const value = input.trim();
  return value.length >= 6 && !/\s/.test(value);
}

/** Both halves are present and usable. */
export function isPanelConfigured(panel: PanelConfig): boolean {
  return isValidBaseUrl(panel.baseUrl) && isValidToken(panel.token);
}

/** The page on the panel where a token can be created by hand. */
export function tokenPageUrl(baseUrl: string): string {
  const base = normalizeBaseUrl(baseUrl);
  return base ? `${base}/token` : '';
}

/**
 * A connection code is a token with the panel address inside it:
 *
 *   kv1.<base64url(panel origin)>.<secret>
 *
 * The panel hands these out, so the user pastes ONE string and never types an address.
 * A plain token (no `kv1.` prefix) is still accepted; it then needs an address.
 */
export function parseConnectionCode(input: string): PanelConfig | null {
  const parts = input.trim().split('.');
  if (parts.length !== 3 || parts[0] !== 'kv1') return null;
  try {
    let b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4) b64 += '=';
    const baseUrl = normalizeBaseUrl(atob(b64));
    const token = parts[2].trim();
    if (!isValidBaseUrl(baseUrl) || !isValidToken(token)) return null;
    return { baseUrl, token };
  } catch {
    return null;
  }
}

/**
 * The panel address built into this APK (set at build time from the PANEL_URL repository
 * variable). When it is present the user only pastes a token. When it is empty the setup
 * screen falls back to asking for the address too.
 */
const RAW_DEFAULT_PANEL_URL = normalizeBaseUrl(process.env.EXPO_PUBLIC_PANEL_URL ?? '');
export const DEFAULT_PANEL_URL: string =
  RAW_DEFAULT_PANEL_URL && !/change-me/i.test(RAW_DEFAULT_PANEL_URL) && isValidBaseUrl(RAW_DEFAULT_PANEL_URL)
    ? RAW_DEFAULT_PANEL_URL
    : '';
