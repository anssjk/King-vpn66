import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';

import { fetchServers, type RemoteServer, type ServerGroup } from '@/lib/api';
import { usePanel } from '@/lib/panel-context';
import {
  connectServer,
  disconnectTunnel,
  getTunnelStatus,
  isAvailable as tunnelAvailable,
  isPrepared,
  requestVpnPermission,
  unavailableReason,
  type TunnelStatus,
} from '@/lib/xray';
import { parseLink, type ServerConfig } from '@/lib/xray-config';

export type ConnStatus = 'disconnected' | 'connecting' | 'connected';

/** A server the app can dial: the panel row plus its parsed config. */
export type ReadyServer = {
  remote: RemoteServer;
  config: ServerConfig;
};

type AppValue = {
  /** True when the user has entered a panel address and token. */
  panelConfigured: boolean;

  /** Every server the panel published, parsed and ready to dial. */
  servers: ReadyServer[];
  /** Rows the panel sent that could not be parsed, with the reason. */
  brokenServers: { remote: RemoteServer; error: string }[];
  serversLoading: boolean;
  serversError: string | null;
  refreshServers: () => Promise<void>;

  /** The group the user picked on the home screen. */
  group: ServerGroup | null;
  setGroup: (group: ServerGroup | null) => void;

  /** Live connection state. */
  status: ConnStatus;
  pingMs: number | null;
  publicIp: string | null;
  error: string | null;
  activeName: string | null;
  tunnel: TunnelStatus | null;
  canTunnel: boolean;
  tunnelUnavailableReason: string | null;
  vpnGranted: boolean;
  requestVpn: () => Promise<boolean>;

  /** Connect to the fastest server in `group` (or the fastest overall). */
  connectFastest: (group?: ServerGroup | null) => Promise<void>;
  /** Connect to one specific server. */
  connectTo: (server: ReadyServer) => Promise<void>;
  disconnect: () => Promise<void>;
};

/** True for a server that is in the Netherlands, judged by its name or its host. */
function isNetherlands(s: ReadyServer): boolean {
  const text = `${s.remote.name ?? ''} ${s.config.name} ${s.config.address}`;
  return (
    /netherlands|holland|amsterdam|هلند|🇳🇱|(^|[^a-z])nl([^a-z]|$)/i.test(text) ||
    /\.nl$/i.test(s.config.address)
  );
}

const AppContext = createContext<AppValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  // The address and token the user entered; every request below uses them.
  const { baseUrl, token, configured } = usePanel();

  const [servers, setServers] = useState<ReadyServer[]>([]);
  const [brokenServers, setBrokenServers] = useState<{ remote: RemoteServer; error: string }[]>([]);
  const [serversLoading, setServersLoading] = useState(false);
  const [serversError, setServersError] = useState<string | null>(null);

  const [group, setGroup] = useState<ServerGroup | null>(null);

  const [status, setStatus] = useState<ConnStatus>('disconnected');
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [publicIp, setPublicIp] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeName, setActiveName] = useState<string | null>(null);
  const [tunnel, setTunnel] = useState<TunnelStatus | null>(null);
  const [vpnGranted, setVpnGranted] = useState(false);

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Read the real permission state once, so the UI never claims a permission it lacks.
  useEffect(() => {
    let alive = true;
    isPrepared().then((granted) => {
      if (alive) setVpnGranted(granted);
    });
    return () => {
      alive = false;
    };
  }, []);

  // Poll the native backend while connected, so the counters and handshake time are live.
  useEffect(() => {
    if (status !== 'connected') {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
      return;
    }
    const tick = async () => {
      const next = await getTunnelStatus();
      if (next) {
        setTunnel(next);
        if (next.state === 'DOWN') {
          setStatus('disconnected');
          setActiveName(null);
        }
      }
    };
    void tick();
    pollRef.current = setInterval(tick, 2000);
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [status]);

  const refreshServers = useCallback(async () => {
    if (!configured) {
      setServers([]);
      setBrokenServers([]);
      setServersError(null);
      return;
    }
    setServersLoading(true);
    setServersError(null);
    try {
      const rows = await fetchServers({ baseUrl, token });
      const ready: ReadyServer[] = [];
      const broken: { remote: RemoteServer; error: string }[] = [];
      for (const remote of rows) {
        const parsed = parseLink(remote.link);
        if (parsed.ok) {
          ready.push({ remote, config: parsed.config });
        } else {
          broken.push({ remote, error: parsed.error });
        }
      }
      setServers(ready);
      setBrokenServers(broken);
    } catch (e) {
      setServersError(e instanceof Error ? e.message : 'Could not load the servers.');
    } finally {
      setServersLoading(false);
    }
  }, [configured, baseUrl, token]);

  // Load the servers as soon as a panel is set, and again whenever it changes — a new
  // address or token means a different list, so the old one is dropped first.
  useEffect(() => {
    if (!configured) {
      setServers([]);
      setBrokenServers([]);
      setServersError(null);
      return;
    }
    void refreshServers();
  }, [configured, refreshServers]);

  const requestVpn = useCallback(async () => {
    const granted = await requestVpnPermission();
    setVpnGranted(granted);
    return granted;
  }, []);

  const connectTo = useCallback(async (server: ReadyServer) => {
    setError(null);
    setPublicIp(null);

    if (!tunnelAvailable) {
      setError(unavailableReason() ?? 'The VPN module is not available in this build.');
      setStatus('disconnected');
      return;
    }

    setStatus('connecting');
    try {
      if (!(await isPrepared())) {
        const granted = await requestVpnPermission();
        setVpnGranted(granted);
        if (!granted) {
          setError('VPN permission was not granted. Accept the system request to connect.');
          setStatus('disconnected');
          return;
        }
      } else {
        setVpnGranted(true);
      }

      await connectServer(server.config);
      setActiveName(server.remote.name ?? server.config.name);
      setStatus('connected');
      setPingMs(null);

      const next = await getTunnelStatus();
      if (next) setTunnel(next);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'The connection failed.');
      setStatus('disconnected');
      setActiveName(null);
      try {
        await disconnectTunnel();
      } catch {
        // Already down.
      }
    }
  }, []);

  const connectFastest = useCallback(
    async (wanted?: ServerGroup | null) => {
      const pool = wanted ? servers.filter((s) => s.remote.group === wanted) : servers;
      if (pool.length === 0) {
        setError(
          wanted
            ? 'No servers in this group yet. Pull to refresh, or check the panel.'
            : 'No servers yet. Pull to refresh, or check the panel.',
        );
        return;
      }
      // The Netherlands is the default: when the pool has a Dutch server, use it. Otherwise
      // "fastest" is the panel's own ordering, which publishes the best first.
      const dutch = pool.find(isNetherlands);
      await connectTo(dutch ?? pool[0]);
    },
    [servers, connectTo],
  );

  const disconnect = useCallback(async () => {
    try {
      await disconnectTunnel();
    } catch {
      // Nothing to tear down.
    }
    setStatus('disconnected');
    setError(null);
    setActiveName(null);
    setPublicIp(null);
    setTunnel(null);
  }, []);

  const value = useMemo<AppValue>(
    () => ({
      panelConfigured: configured,
      servers,
      brokenServers,
      serversLoading,
      serversError,
      refreshServers,
      group,
      setGroup,
      status,
      pingMs,
      publicIp,
      error,
      activeName,
      tunnel,
      canTunnel: tunnelAvailable,
      tunnelUnavailableReason: unavailableReason(),
      vpnGranted,
      requestVpn,
      connectFastest,
      connectTo,
      disconnect,
    }),
    [
      configured,
      servers,
      brokenServers,
      serversLoading,
      serversError,
      refreshServers,
      group,
      status,
      pingMs,
      publicIp,
      error,
      activeName,
      tunnel,
      vpnGranted,
      requestVpn,
      connectFastest,
      connectTo,
      disconnect,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppValue {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return value;
}
