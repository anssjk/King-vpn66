/**
 * One-shot flag: set after the panel was just created for the user, so the home screen
 * connects on its own as soon as the server list is in. Not persisted on purpose.
 */
export const autoConnect = { pending: false };
