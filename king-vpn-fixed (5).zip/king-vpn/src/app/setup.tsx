import Ionicons from '@expo/vector-icons/Ionicons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { BrandMark, Button, Card, TextField } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { testPanel } from '@/lib/api';
import { autoConnect } from '@/lib/auto-connect';
import { deployPanel, type DeployStep } from '@/lib/railway';
import {
  DEFAULT_PANEL_URL,
  PANEL_REPO,
  isValidBaseUrl,
  isValidToken,
  normalizeBaseUrl,
  parseConnectionCode,
  tokenPageUrl,
} from '@/lib/config';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { usePanel } from '@/lib/panel-context';
import { useSettings } from '@/lib/settings-context';

/**
 * First-launch setup: the panel address and the token.
 *
 * Both are typed here, checked against the panel, and then kept on the device. The same
 * screen is opened again from Settings (with `?edit=1`) to change them, so a user never
 * needs a new APK when the panel moves or the token is rotated.
 */
export default function SetupScreen() {
  const colors = useColors();
  const router = useRouter();
  const { t, rtl } = useSettings();
  const { baseUrl, token, save } = usePanel();
  const params = useLocalSearchParams<{ edit?: string }>();
  const editing = params.edit === '1';

  const [url, setUrl] = useState(baseUrl);
  const [secret, setSecret] = useState(token);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);
  // The address field only appears when the pasted value is a plain token with no address in it.
  const [needUrl, setNeedUrl] = useState(false);

  // Page one is the Railway one-button flow; the code/token form is the second option.
  const [rwToken, setRwToken] = useState('');
  const [rwStep, setRwStep] = useState<DeployStep | null>(null);
  const [showCode, setShowCode] = useState(editing || Boolean(baseUrl));

  const onDeploy = async () => {
    tapFeedback();
    setError(null);
    if (!PANEL_REPO) {
      setError(t('rwNoRepo'));
      return;
    }
    if (rwToken.trim().length < 20) {
      setError(t('setupErrorToken'));
      return;
    }
    try {
      const panel = await deployPanel(rwToken, PANEL_REPO, setRwStep);
      setRwToken('');
      save(panel);
      autoConnect.pending = true;
      successFeedback();
      router.replace('/(tabs)');
    } catch (e) {
      setError(e instanceof Error ? e.message : t('setupErrorReach'));
    } finally {
      setRwStep(null);
    }
  };

  const finish = () => {
    save(parseConnectionCode(secret) ?? { baseUrl: url || baseUrl || DEFAULT_PANEL_URL, token: secret });
    successFeedback();
    if (editing) {
      router.back();
    } else {
      router.replace('/(tabs)');
    }
  };

  const onSubmit = async () => {
    tapFeedback();
    setError(null);
    setFailed(false);

    const code = parseConnectionCode(secret);
    let target = code;
    if (!target) {
      const knownUrl = url || baseUrl || DEFAULT_PANEL_URL;
      if (!isValidToken(secret)) {
        setError(t('setupErrorToken'));
        return;
      }
      if (!isValidBaseUrl(knownUrl)) {
        setNeedUrl(true);
        setError(url ? t('setupErrorUrl') : t('setupNeedsUrl'));
        return;
      }
      target = { baseUrl: normalizeBaseUrl(knownUrl), token: secret.trim() };
    }

    setBusy(true);
    const result = await testPanel(target);
    setBusy(false);
    if (result.ok) {
      save(target);
      successFeedback();
      if (editing) router.back();
      else router.replace('/(tabs)');
      return;
    }

    if (!result.ok) {
      setError(result.message ?? t('setupErrorReach'));
      setFailed(true);
      return;
    }
    finish();
  };

  return (
    <Screen contentStyle={{ gap: spacing.md }}>
      <View style={[styles.head, rtl && styles.rowReverse]}>
        <BrandMark size={44} withWordmark />
      </View>

      {showCode ? (
      <View style={styles.intro}>
        <Text style={[styles.title, { color: colors.text }]}>{t('setupTitle')}</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>{t('setupSubtitle')}</Text>
      </View>
      ) : null}

      {showCode && DEFAULT_PANEL_URL ? (
        <Pressable
          accessibilityRole="link"
          onPress={() => {
            tapFeedback();
            void Linking.openURL(tokenPageUrl(DEFAULT_PANEL_URL));
          }}
          style={({ pressed }) => [
            styles.note,
            { backgroundColor: colors.card, borderColor: colors.border },
            pressed && { opacity: 0.8 },
          ]}>
          <Ionicons name="link-outline" size={17} color={colors.primary} />
          <View style={{ flex: 1, gap: 2 }}>
            <Text style={[styles.noteText, { color: colors.muted }]}>{t('getTokenAt')}</Text>
            <Text style={[styles.noteText, { color: colors.primary, fontWeight: '800' }]} selectable>
              {tokenPageUrl(DEFAULT_PANEL_URL)}
            </Text>
          </View>
        </Pressable>
      ) : null}

      {!showCode ? (
        <Card style={styles.form}>
          <Text style={[styles.title, { color: colors.text, fontSize: 20 }]}>{t('rwTitle')}</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>{t('rwSubtitle')}</Text>
          <TextField
            label={t('rwLabel')}
            value={rwToken}
            onChangeText={setRwToken}
            hint={t('rwHint')}
            autoCapitalize="none"
            autoCorrect={false}
            secureTextEntry
            editable={!rwStep}
          />
          {rwStep ? (
            <Text style={[styles.noteText, { color: colors.primary }]}>{t(`rwStep_${rwStep}` as never)}</Text>
          ) : null}
          {error ? (
            <View style={[styles.errorBox, { borderColor: colors.danger }]}>
              <Ionicons name="alert-circle" size={17} color={colors.danger} />
              <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
            </View>
          ) : null}
          <Button
            title={t('rwButton')}
            onPress={() => void onDeploy()}
            loading={Boolean(rwStep)}
            icon="rocket-outline"
          />
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              tapFeedback();
              setError(null);
              setShowCode(true);
            }}
            style={({ pressed }) => [styles.linkBtn, pressed && { opacity: 0.7 }]}>
            <Text style={[styles.linkText, { color: colors.muted }]}>{t('rwHave')}</Text>
          </Pressable>
        </Card>
      ) : null}

      {showCode ? (
      <Card style={styles.form}>
        {needUrl && !DEFAULT_PANEL_URL ? (
        <TextField
          label={t('panelUrl')}
          value={url}
          onChangeText={setUrl}
          placeholder={t('panelUrlPlaceholder')}
          hint={t('panelUrlHint')}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          inputMode="url"
          textContentType="URL"
          editable={!busy}
        />
        ) : null}
        <TextField
          label={t('panelToken')}
          value={secret}
          onChangeText={setSecret}
          placeholder={t('panelTokenPlaceholder')}
          hint={t('panelTokenHint')}
          autoCapitalize="none"
          autoCorrect={false}
          editable={!busy}
        />

        {error ? (
          <View style={[styles.errorBox, { borderColor: colors.danger }]}>
            <Ionicons name="alert-circle" size={17} color={colors.danger} />
            <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
          </View>
        ) : null}

        <Button
          title={busy ? t('testing') : t('testAndSave')}
          onPress={() => void onSubmit()}
          loading={busy}
          icon="checkmark-circle-outline"
        />

        {failed ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              tapFeedback();
              finish();
            }}
            style={({ pressed }) => [styles.linkBtn, pressed && { opacity: 0.7 }]}>
            <Text style={[styles.linkText, { color: colors.muted }]}>{t('saveAnyway')}</Text>
          </Pressable>
        ) : null}
      </Card>
      ) : null}

      {showCode ? (
      <View style={[styles.note, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Ionicons name="information-circle-outline" size={17} color={colors.muted} />
        <Text style={[styles.noteText, { color: colors.muted }]}>{t('setupNote')}</Text>
      </View>
      ) : null}

      {editing ? (
        <Pressable
          accessibilityRole="button"
          onPress={() => {
            tapFeedback();
            router.back();
          }}
          style={({ pressed }) => [styles.linkBtn, pressed && { opacity: 0.7 }]}>
          <Text style={[styles.linkText, { color: colors.primary }]}>{t('cancel')}</Text>
        </Pressable>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rowReverse: { flexDirection: 'row-reverse' },
  intro: { gap: 4 },
  title: { fontSize: 26, fontWeight: '900', letterSpacing: -0.6 },
  subtitle: { fontSize: 13.5, lineHeight: 20 },
  form: { gap: spacing.md },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 10,
  },
  errorText: { flex: 1, fontSize: 12.5, lineHeight: 18 },
  linkBtn: { alignItems: 'center', paddingVertical: 8 },
  linkText: { fontSize: 13.5, fontWeight: '700' },
  note: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  noteText: { flex: 1, fontSize: 12.5, lineHeight: 18 },
});
