import type { PanelConfig } from '@/lib/config';

/**
 * Creates the user's own panel on their Railway account with one token.
 *
 * Steps: check the token → create a project → create the service from the public panel repo
 * → put it in Amsterdam (the Netherlands) → give it a public domain → wait until it answers
 * → ask it for an access token. The Railway token is used only inside this function and is
 * never stored.
 */
const API = 'https://backboard.railway.com/graphql/v2';
const REGION_NETHERLANDS = 'europe-west4-drams3a';

export type DeployStep = 'check' | 'project' | 'service' | 'region' | 'domain' | 'wait' | 'token';

export class RailwayError extends Error {}

type GqlResponse<T> = { data?: T; errors?: { message: string }[] };

const ENDPOINTS = ['https://backboard.railway.com/graphql/v2', 'https://backboard.railway.app/graphql/v2'];

async function gql<T>(token: string, query: string, variables: Record<string, unknown>): Promise<T> {
  let last: RailwayError = new RailwayError('Could not reach Railway.');
  for (const endpoint of ENDPOINTS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'User-Agent': 'king-vpn/1.0',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ query, variables }),
      });
      const raw = await res.text();
      let body: GqlResponse<T> = {};
      try {
        body = JSON.parse(raw) as GqlResponse<T>;
      } catch {
        body = {};
      }
      if (body.errors?.length) throw new RailwayError(body.errors[0].message);
      if (res.ok && body.data) return body.data;
      // Not a GraphQL answer (a 403 page, for instance): keep the status and a bit of the
      // text so the real cause is visible, then try the other address.
      last = new RailwayError(`Railway answered ${res.status}: ${raw.replace(/\s+/g, ' ').slice(0, 140)}`);
    } catch (e) {
      if (e instanceof RailwayError) throw e;
      last = new RailwayError('Could not reach Railway. Check the internet and try again.');
    } finally {
      clearTimeout(timer);
    }
  }
  throw last;
}

function randomKey(): string {
  const bytes = new Uint8Array(24);
  for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function deployPanel(
  railwayToken: string,
  repo: string,
  onStep: (step: DeployStep) => void,
): Promise<PanelConfig> {
  const token = railwayToken.trim();

  onStep('check');
  await gql<{ me: { name: string } }>(token, 'query { me { name } }', {});
  // New Railway accounts create projects inside a workspace; ask for it when there is one.
  let workspaceId: string | undefined;
  try {
    const w = await gql<{ me: { workspaces: { id: string }[] } }>(
      token,
      'query { me { workspaces { id } } }',
      {},
    );
    workspaceId = w.me.workspaces?.[0]?.id;
  } catch {
    workspaceId = undefined;
  }

  onStep('project');
  const project = await gql<{
    projectCreate: { id: string; environments: { edges: { node: { id: string } }[] } };
  }>(
    token,
    `mutation($input: ProjectCreateInput!) {
       projectCreate(input: $input) { id environments { edges { node { id } } } }
     }`,
    { input: { name: `king-vpn-${Date.now().toString(36)}`, ...(workspaceId ? { workspaceId } : {}) } },
  );
  const projectId = project.projectCreate.id;
  const environmentId = project.projectCreate.environments.edges[0]?.node.id;
  if (!environmentId) throw new RailwayError('Railway made the project but no environment.');

  onStep('service');
  const service = await gql<{ serviceCreate: { id: string } }>(
    token,
    `mutation($input: ServiceCreateInput!) { serviceCreate(input: $input) { id } }`,
    {
      input: {
        projectId,
        environmentId,
        name: 'panel',
        source: { repo },
        branch: 'panel',
        variables: { ADMIN_KEY: randomKey(), PORT: '3000' },
      },
    },
  );
  const serviceId = service.serviceCreate.id;

  onStep('region');
  try {
    await gql(
      token,
      `mutation($serviceId: String!, $environmentId: String!, $input: ServiceInstanceUpdateInput!) {
         serviceInstanceUpdate(serviceId: $serviceId, environmentId: $environmentId, input: $input)
       }`,
      { serviceId, environmentId, input: { region: REGION_NETHERLANDS } },
    );
  } catch {
    // The region is a preference: the panel still works from Railway's default one.
  }

  onStep('domain');
  const domain = await gql<{ serviceDomainCreate: { domain: string } }>(
    token,
    `mutation($input: ServiceDomainCreateInput!) { serviceDomainCreate(input: $input) { domain } }`,
    { input: { serviceId, environmentId, targetPort: 3000 } },
  );
  const baseUrl = `https://${domain.serviceDomainCreate.domain}`;

  onStep('wait');
  let up = false;
  for (let i = 0; i < 100 && !up; i += 1) {
    await sleep(6000);
    try {
      const res = await fetch(`${baseUrl}/health`);
      up = res.ok;
    } catch {
      up = false;
    }
  }
  if (!up) {
    throw new RailwayError('The panel is still building. Open Railway to see it, then try again in a few minutes.');
  }

  onStep('token');
  const res = await fetch(`${baseUrl}/api/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ label: 'app' }),
  });
  const body = (await res.json().catch(() => ({}))) as { token?: string };
  if (!res.ok || !body.token) throw new RailwayError('The panel is up but did not give a token.');
  return { baseUrl, token: body.token };
}
