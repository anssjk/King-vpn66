import { createContext, useCallback, useContext, useMemo, type ReactNode } from 'react';

import { usePersistentState } from '@/hooks/use-persistent-state';
import {
  EMPTY_PANEL,
  isPanelConfigured,
  normalizeBaseUrl,
  type PanelConfig,
} from '@/lib/config';

type PanelValue = {
  /** Panel base URL, normalised (scheme present, no trailing slash). */
  baseUrl: string;
  /** The token the user entered. */
  token: string;
  /** True when both halves are present and usable. */
  configured: boolean;
  /** False while the stored values are still being read from the device. */
  ready: boolean;
  /** Store a new address + token. The address is normalised first. */
  save: (next: PanelConfig) => void;
  /** Forget both, which sends the app back to the setup screen. */
  clear: () => void;
};

const PanelContext = createContext<PanelValue | null>(null);

/**
 * The panel connection, kept on the device.
 *
 * Nothing is baked in at build time, so one APK works for every user: whoever installs it
 * types their own address and token on first launch, and can change them later from
 * Settings. Every request in `lib/api` reads them from here.
 */
export function PanelProvider({ children }: { children: ReactNode }) {
  const [panel, setPanel, status] = usePersistentState<PanelConfig>('panel', EMPTY_PANEL);

  const save = useCallback(
    (next: PanelConfig) => {
      setPanel({ baseUrl: normalizeBaseUrl(next.baseUrl), token: next.token.trim() });
    },
    [setPanel],
  );

  const clear = useCallback(() => setPanel(EMPTY_PANEL), [setPanel]);

  const value = useMemo<PanelValue>(
    () => ({
      baseUrl: panel.baseUrl,
      token: panel.token,
      configured: isPanelConfigured(panel),
      ready: status !== 'loading',
      save,
      clear,
    }),
    [panel, status, save, clear],
  );

  return <PanelContext.Provider value={value}>{children}</PanelContext.Provider>;
}

export function usePanel(): PanelValue {
  const value = useContext(PanelContext);
  if (!value) {
    throw new Error('usePanel must be used inside PanelProvider');
  }
  return value;
}
