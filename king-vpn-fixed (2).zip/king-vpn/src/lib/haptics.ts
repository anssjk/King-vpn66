import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

/**
 * Light touch feedback. Haptics do nothing on the web preview and can throw on devices
 * without a vibrator, so every call is guarded and its failure ignored.
 */
export function tapFeedback(): void {
  if (Platform.OS === 'web') return;
  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
}

export function successFeedback(): void {
  if (Platform.OS === 'web') return;
  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
}
