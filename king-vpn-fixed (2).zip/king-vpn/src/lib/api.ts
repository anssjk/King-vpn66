/**
 * Client for the KING VPN panel backend (deployed on Railway).
 *
 * Every call takes the panel the user entered on the setup screen, so the app has no
 * build-time address: the same APK talks to whichever panel its owner typed in. The
 * token is the one the user pasted, and it is sent on every request.
 *
 * Nothing here invents data: if the panel is unreachable the call throws and the UI says
 * so, instead of showing a fake list.
 */
import { normalizeBaseUrl, type PanelConfig } from '@/lib/config';

/** One server as the panel stores it: a group plus the share link it was added from. */
export type RemoteServer = {
  id: string;
  group: ServerGroup;
  link: string;
  name?: string;
};

export type ServerGroup = 'trojan' | 'vless' | 'vmess' | 'vless-hu';

export const SERVER_GROUPS: ServerGroup[] = ['trojan', 'vless', 'vmess', 'vless-hu'];

const TIMEOUT_MS = 15000;

async function request<T>(panel: PanelConfig, path: string, init: RequestInit = {}): Promise<T> {
  const base = normalizeBaseUrl(panel.baseUrl);
  if (!base) {
    throw new Error('No panel address is set.');
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(`${base}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
        ...(panel.token ? { 'x-api-token': panel.token } : {}),
        ...(init.headers ?? {}),
      },
    });

    const text = await res.text();
    let body: unknown = null;
    if (text) {
      try {
        body = JSON.parse(text) as unknown;
      } catch {
        // A proxy or a wrong address can answer with HTML; treat it as no body.
        body = null;
      }
    }

    if (!res.ok) {
      const message =
        body && typeof body === 'object' && 'error' in body
          ? String((body as { error: unknown }).error)
          : `The panel answered ${res.status}.`;
      throw new Error(message);
    }
    return body as T;
  } catch (e) {
    if (e instanceof Error && e.name === 'AbortError') {
      throw new Error('The panel did not answer in time. Check the address and your connection.');
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

/** Check that the panel accepts this token. */
export async function verifyToken(panel: PanelConfig): Promise<boolean> {
  const res = await request<{ valid: boolean }>(
    panel,
    `/api/token/${encodeURIComponent(panel.token)}`,
  );
  return Boolean(res.valid);
}

/** The servers the panel publishes for this token, best first. */
export async function fetchServers(panel: PanelConfig): Promise<RemoteServer[]> {
  const res = await request<{ servers: RemoteServer[] }>(panel, '/api/servers');
  return Array.isArray(res.servers) ? res.servers : [];
}

export type PanelTest = { ok: boolean; message?: string };

/**
 * Reach the panel and check the token in one call, for the setup screen. It never throws:
 * the caller shows `message` next to the fields.
 */
export async function testPanel(panel: PanelConfig): Promise<PanelTest> {
  try {
    const valid = await verifyToken(panel);
    if (!valid) {
      return { ok: false, message: 'The panel rejected this token.' };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, message: e instanceof Error ? e.message : 'Could not reach the panel.' };
  }
}
