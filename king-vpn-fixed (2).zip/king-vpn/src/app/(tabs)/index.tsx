import { HomePanel } from '@/components/home-panel';

/**
 * Page 1 — the connect panel: one "Fastest country" button and the four group buttons
 * (Trojan / VLESS / VMess / VLESS HU). No token field, no WARP, no scanner.
 */
export default function HomeScreen() {
  return <HomePanel />;
}
