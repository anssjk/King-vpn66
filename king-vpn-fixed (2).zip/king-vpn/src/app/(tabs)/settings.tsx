import Ionicons from '@expo/vector-icons/Ionicons';
import Constants from 'expo-constants';
import * as Clipboard from 'expo-clipboard';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { BrandMark, Card, ConfirmDialog, SectionHeader, Segmented, type SegmentOption } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import { tokenPageUrl } from '@/lib/config';
import { tapFeedback } from '@/lib/haptics';
import type { Lang } from '@/lib/i18n';
import { CHANNEL_HANDLE, OWNER_HANDLE, TELEGRAM_CHANNEL, TELEGRAM_OWNER } from '@/lib/links';
import { usePanel } from '@/lib/panel-context';
import { useSettings, type ThemeMode } from '@/lib/settings-context';

const VERSION = Constants.expoConfig?.version ?? '1.0.0';

/**
 * Settings: the panel connection, channel, owner and appearance.
 *
 * The panel address and token are the user's own — typed on the setup screen and kept on
 * this device. This page shows them (the token masked), opens the setup screen again to
 * change them, and can forget them entirely.
 */
export default function SettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { t, lang, setLang, theme, setTheme, rtl } = useSettings();
  const { baseUrl, token, configured, clear } = usePanel();
  const { refreshServers } = useApp();
  const [copied, setCopied] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const open = (url: string) => {
    tapFeedback();
    if (!url) return;
    Linking.openURL(url).catch(() => {});
  };

  const langOptions: SegmentOption<Lang>[] = [
    { value: 'en', label: 'English' },
    { value: 'fa', label: 'فارسی' },
  ];
  const themeOptions: SegmentOption<ThemeMode>[] = [
    { value: 'light', label: t('light'), icon: 'sunny-outline' },
    { value: 'dark', label: t('dark'), icon: 'moon-outline' },
  ];

  const copyToken = async () => {
    if (!token) return;
    tapFeedback();
    await Clipboard.setStringAsync(token);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  return (
    <Screen bottomInset={96}>
      <View style={styles.pageHead}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>{t('settingsTitle')}</Text>
        <Text style={[styles.pageSubtitle, { color: colors.muted }]}>{t('settingsSubtitle')}</Text>
      </View>

      {/* Brand hero */}
      <View style={styles.heroCard}>
        <LinearGradient
          colors={colors.gradientHero}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[StyleSheet.absoluteFill, { borderRadius: radius.xl }]}
        />
        <View style={[styles.heroInner, { borderColor: colors.border }]}>
          <BrandMark size={52} />
          <View style={styles.heroText}>
            <Text style={[styles.heroTitle, { color: colors.text }]}>
              KING <Text style={{ color: colors.primary }}>VPN</Text>
            </Text>
            <Text style={[styles.heroTagline, { color: colors.muted }]}>{t('tagline')}</Text>
          </View>
          <View style={[styles.versionPill, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.versionText, { color: colors.muted }]}>v{VERSION}</Text>
          </View>
        </View>
      </View>

      {/* Panel connection — the address and token this device uses */}
      <SectionHeader title={t('account')} subtitle={t('tokenHint')} />
      <Card style={styles.tokenCard}>
        <View style={[styles.prefRow, rtl && styles.rowReverse]}>
          <View style={[styles.prefIcon, { backgroundColor: colors.cardAlt }]}>
            <Ionicons name="globe-outline" size={18} color={colors.primary} />
          </View>
          <View style={styles.tokenInfo}>
            <Text style={[styles.prefLabel, { color: colors.text }]}>{t('panelAddress')}</Text>
            <Text
              style={[styles.tokenValue, { color: configured ? colors.muted : colors.faint }]}
              numberOfLines={1}>
              {baseUrl || t('notConfigured')}
            </Text>
          </View>
        </View>

        <View style={[styles.prefRow, rtl && styles.rowReverse]}>
          <View style={[styles.prefIcon, { backgroundColor: colors.cardAlt }]}>
            <Ionicons name="key" size={18} color={colors.primary} />
          </View>
          <View style={styles.tokenInfo}>
            <Text style={[styles.prefLabel, { color: colors.text }]}>{t('token')}</Text>
            <Text style={[styles.tokenValue, { color: token ? colors.muted : colors.faint }]} numberOfLines={1}>
              {token ? maskToken(token) : t('tokenMissing')}
            </Text>
          </View>
          {token ? (
            <Pressable
              onPress={copyToken}
              style={({ pressed }) => [
                styles.smallBtn,
                { backgroundColor: colors.cardAlt, borderColor: colors.border },
                pressed && { opacity: 0.8 },
              ]}>
              <Ionicons name={copied ? 'checkmark' : 'copy-outline'} size={14} color={colors.primary} />
              <Text style={[styles.smallBtnText, { color: colors.primary }]}>
                {copied ? t('copied') : t('copy')}
              </Text>
            </Pressable>
          ) : null}
        </View>

        <Pressable
          accessibilityRole="button"
          onPress={() => {
            tapFeedback();
            router.push({ pathname: '/setup', params: { edit: '1' } });
          }}
          style={({ pressed }) => [
            styles.actionBtn,
            { backgroundColor: colors.cardAlt, borderColor: colors.border },
            pressed && { opacity: 0.8 },
          ]}>
          <Ionicons name="create-outline" size={15} color={colors.primary} />
          <Text style={[styles.actionText, { color: colors.primary }]}>{t('editPanel')}</Text>
        </Pressable>

        {configured ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              tapFeedback();
              void refreshServers();
            }}
            style={({ pressed }) => [
              styles.actionBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            <Ionicons name="refresh" size={15} color={colors.primary} />
            <Text style={[styles.actionText, { color: colors.primary }]}>{t('refresh')}</Text>
          </Pressable>
        ) : null}

        {configured ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => open(tokenPageUrl(baseUrl))}
            style={({ pressed }) => [
              styles.actionBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            <Ionicons name="open-outline" size={15} color={colors.primary} />
            <View style={styles.actionTextWrap}>
              <Text style={[styles.actionText, { color: colors.primary }]}>{t('tokenPage')}</Text>
              <Text style={[styles.actionHint, { color: colors.faint }]}>{t('tokenPageHint')}</Text>
            </View>
          </Pressable>
        ) : null}

        {configured ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              tapFeedback();
              setConfirmClear(true);
            }}
            style={({ pressed }) => [
              styles.actionBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            <Ionicons name="trash-outline" size={15} color={colors.danger} />
            <Text style={[styles.actionText, { color: colors.danger }]}>{t('clearPanel')}</Text>
          </Pressable>
        ) : null}
      </Card>

      {/* Channel + owner */}
      <SectionHeader title={t('channel')} />
      <LinkCard
        icon="paper-plane"
        iconColors={['#2AABEE', '#229ED9']}
        label={t('channel')}
        value={CHANNEL_HANDLE}
        hint={t('channelHint')}
        onPress={() => open(TELEGRAM_CHANNEL)}
        rtl={rtl}
      />
      <LinkCard
        icon="person"
        iconColors={colors.gradientBrand}
        label={t('owner')}
        value={OWNER_HANDLE}
        hint={t('ownerHint')}
        onPress={() => open(TELEGRAM_OWNER)}
        rtl={rtl}
      />

      {/* Appearance */}
      <SectionHeader title={t('preferences')} />
      <Card style={styles.prefCard}>
        <View style={styles.prefRow}>
          <View style={[styles.prefIcon, { backgroundColor: colors.cardAlt }]}>
            <Ionicons name="language" size={18} color={colors.primary} />
          </View>
          <Text style={[styles.prefLabel, { color: colors.text }]}>{t('language')}</Text>
        </View>
        <Segmented options={langOptions} value={lang} onChange={setLang} />

        <View style={[styles.divider, { backgroundColor: colors.border }]} />

        <View style={styles.prefRow}>
          <View style={[styles.prefIcon, { backgroundColor: colors.cardAlt }]}>
            <Ionicons name={theme === 'dark' ? 'moon' : 'sunny'} size={18} color={colors.primary} />
          </View>
          <Text style={[styles.prefLabel, { color: colors.text }]}>{t('theme')}</Text>
        </View>
        <Segmented options={themeOptions} value={theme} onChange={setTheme} />
      </Card>

      <Text style={[styles.footer, { color: colors.faint }]}>
        KING VPN · {t('version')} {VERSION}
      </Text>

      <ConfirmDialog
        visible={confirmClear}
        title={t('clearPanelTitle')}
        message={t('clearPanelMessage')}
        confirmTitle={t('forget')}
        cancelTitle={t('cancel')}
        destructive
        onCancel={() => setConfirmClear(false)}
        onConfirm={() => {
          setConfirmClear(false);
          clear();
          router.replace('/setup');
        }}
      />
    </Screen>
  );
}

/** Show only the ends of a token, so a screenshot does not leak it. */
function maskToken(token: string): string {
  if (token.length <= 10) return '••••••';
  return `${token.slice(0, 4)}••••••${token.slice(-4)}`;
}

function LinkCard({
  icon,
  iconColors,
  label,
  value,
  hint,
  onPress,
  rtl,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  iconColors: readonly [string, string, ...string[]];
  label: string;
  value: string;
  hint: string;
  onPress: () => void;
  rtl: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.linkCard,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && { opacity: 0.85, transform: [{ scale: 0.99 }] },
      ]}>
      <LinearGradient colors={iconColors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.linkIcon}>
        <Ionicons name={icon} size={20} color="#FFFFFF" />
      </LinearGradient>
      <View style={styles.linkInfo}>
        <Text style={[styles.linkLabel, { color: colors.faint }]}>{label}</Text>
        <Text style={[styles.linkValue, { color: colors.text }]} numberOfLines={1}>
          {value}
        </Text>
        <Text style={[styles.linkHint, { color: colors.muted }]} numberOfLines={1}>
          {hint}
        </Text>
      </View>
      <View style={[styles.openBtn, { backgroundColor: colors.cardAlt }]}>
        <Ionicons name={rtl ? 'arrow-back' : 'arrow-forward'} size={16} color={colors.primary} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pageHead: { gap: 3, marginBottom: spacing.xs },
  pageTitle: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6 },
  pageSubtitle: { fontSize: 13.5, lineHeight: 19 },
  heroCard: { borderRadius: radius.xl, overflow: 'hidden' },
  heroInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.xl,
  },
  heroText: { flex: 1, gap: 2 },
  heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.5 },
  heroTagline: { fontSize: 12.5 },
  versionPill: {
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  versionText: { fontSize: 11.5, fontWeight: '800' },
  prefCard: { gap: spacing.sm },
  prefRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  rowReverse: { flexDirection: 'row-reverse' },
  prefIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  prefLabel: { fontSize: 15, fontWeight: '700' },
  divider: { height: StyleSheet.hairlineWidth, marginVertical: 4 },
  linkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  linkIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  linkInfo: { flex: 1, gap: 1 },
  linkLabel: { fontSize: 11, fontWeight: '800', letterSpacing: 0.6, textTransform: 'uppercase' },
  linkValue: { fontSize: 15, fontWeight: '700' },
  linkHint: { fontSize: 11.5 },
  openBtn: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  tokenCard: { gap: spacing.sm },
  tokenInfo: { flex: 1, gap: 2 },
  tokenValue: { fontSize: 12.5, fontWeight: '600' },
  smallBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  smallBtnText: { fontSize: 11.5, fontWeight: '800' },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingVertical: 11,
    paddingHorizontal: spacing.md,
  },
  actionTextWrap: { flex: 1, gap: 1 },
  actionText: { fontSize: 13.5, fontWeight: '800' },
  actionHint: { fontSize: 11 },
  errorText: { fontSize: 12, lineHeight: 17 },
  footer: { fontSize: 12, textAlign: 'center', marginTop: spacing.md },
});
