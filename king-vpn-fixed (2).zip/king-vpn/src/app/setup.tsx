import Ionicons from '@expo/vector-icons/Ionicons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { BrandMark, Button, Card, TextField } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { testPanel } from '@/lib/api';
import { isValidBaseUrl, isValidToken, normalizeBaseUrl } from '@/lib/config';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { usePanel } from '@/lib/panel-context';
import { useSettings } from '@/lib/settings-context';

/**
 * First-launch setup: the panel address and the token.
 *
 * Both are typed here, checked against the panel, and then kept on the device. The same
 * screen is opened again from Settings (with `?edit=1`) to change them, so a user never
 * needs a new APK when the panel moves or the token is rotated.
 */
export default function SetupScreen() {
  const colors = useColors();
  const router = useRouter();
  const { t, rtl } = useSettings();
  const { baseUrl, token, save } = usePanel();
  const params = useLocalSearchParams<{ edit?: string }>();
  const editing = params.edit === '1';

  const [url, setUrl] = useState(baseUrl);
  const [secret, setSecret] = useState(token);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);

  const finish = () => {
    save({ baseUrl: url, token: secret });
    successFeedback();
    if (editing) {
      router.back();
    } else {
      router.replace('/(tabs)');
    }
  };

  const onSubmit = async () => {
    tapFeedback();
    setError(null);
    setFailed(false);

    if (!isValidBaseUrl(url)) {
      setError(t('setupErrorUrl'));
      return;
    }
    if (!isValidToken(secret)) {
      setError(t('setupErrorToken'));
      return;
    }

    setBusy(true);
    const result = await testPanel({ baseUrl: normalizeBaseUrl(url), token: secret.trim() });
    setBusy(false);

    if (!result.ok) {
      setError(result.message ?? t('setupErrorReach'));
      setFailed(true);
      return;
    }
    finish();
  };

  return (
    <Screen contentStyle={{ gap: spacing.md }}>
      <View style={[styles.head, rtl && styles.rowReverse]}>
        <BrandMark size={44} withWordmark />
      </View>

      <View style={styles.intro}>
        <Text style={[styles.title, { color: colors.text }]}>{t('setupTitle')}</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>{t('setupSubtitle')}</Text>
      </View>

      <Card style={styles.form}>
        <TextField
          label={t('panelUrl')}
          value={url}
          onChangeText={setUrl}
          placeholder={t('panelUrlPlaceholder')}
          hint={t('panelUrlHint')}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          inputMode="url"
          textContentType="URL"
          editable={!busy}
        />
        <TextField
          label={t('panelToken')}
          value={secret}
          onChangeText={setSecret}
          placeholder={t('panelTokenPlaceholder')}
          hint={t('panelTokenHint')}
          autoCapitalize="none"
          autoCorrect={false}
          secureTextEntry
          editable={!busy}
        />

        {error ? (
          <View style={[styles.errorBox, { borderColor: colors.danger }]}>
            <Ionicons name="alert-circle" size={17} color={colors.danger} />
            <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
          </View>
        ) : null}

        <Button
          title={busy ? t('testing') : t('testAndSave')}
          onPress={() => void onSubmit()}
          loading={busy}
          icon="checkmark-circle-outline"
        />

        {failed ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              tapFeedback();
              finish();
            }}
            style={({ pressed }) => [styles.linkBtn, pressed && { opacity: 0.7 }]}>
            <Text style={[styles.linkText, { color: colors.muted }]}>{t('saveAnyway')}</Text>
          </Pressable>
        ) : null}
      </Card>

      <View style={[styles.note, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Ionicons name="information-circle-outline" size={17} color={colors.muted} />
        <Text style={[styles.noteText, { color: colors.muted }]}>{t('setupNote')}</Text>
      </View>

      {editing ? (
        <Pressable
          accessibilityRole="button"
          onPress={() => {
            tapFeedback();
            router.back();
          }}
          style={({ pressed }) => [styles.linkBtn, pressed && { opacity: 0.7 }]}>
          <Text style={[styles.linkText, { color: colors.primary }]}>{t('cancel')}</Text>
        </Pressable>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rowReverse: { flexDirection: 'row-reverse' },
  intro: { gap: 4 },
  title: { fontSize: 26, fontWeight: '900', letterSpacing: -0.6 },
  subtitle: { fontSize: 13.5, lineHeight: 20 },
  form: { gap: spacing.md },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 10,
  },
  errorText: { flex: 1, fontSize: 12.5, lineHeight: 18 },
  linkBtn: { alignItems: 'center', paddingVertical: 8 },
  linkText: { fontSize: 13.5, fontWeight: '700' },
  note: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  noteText: { flex: 1, fontSize: 12.5, lineHeight: 18 },
});
