import { LinearGradient } from 'expo-linear-gradient';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { useColors } from '@/constants/theme';

/**
 * The app's signature backdrop: a soft vertical wash with three large, faded colour
 * blobs (cyan, blue, violet) that give every screen the "aurora" depth. It sits behind
 * the content and never takes touches.
 */
export function AuroraBackground() {
  const colors = useColors();
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <LinearGradient
        colors={[colors.background, colors.backgroundAlt, colors.background]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <Blob size={360} color={colors.auroraA} style={styles.blobTop} />
      <Blob size={300} color={colors.auroraB} style={styles.blobRight} />
      <Blob size={280} color={colors.auroraC} style={styles.blobBottom} />
    </View>
  );
}

function Blob({ size, color, style }: { size: number; color: string; style?: StyleProp<ViewStyle> }) {
  return (
    <LinearGradient
      colors={[color, 'transparent']}
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={[{ width: size, height: size, borderRadius: size / 2 }, style]}
    />
  );
}

const styles = StyleSheet.create({
  blobTop: { position: 'absolute', top: -120, left: -110 },
  blobRight: { position: 'absolute', top: 140, right: -140 },
  blobBottom: { position: 'absolute', bottom: -90, left: 30 },
});
