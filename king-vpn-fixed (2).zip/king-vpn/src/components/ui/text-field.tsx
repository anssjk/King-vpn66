import { useState } from 'react';
import { StyleSheet, Text, TextInput, View, type TextInputProps } from 'react-native';

import { radius, spacing, useColors } from '@/constants/theme';

type Props = TextInputProps & {
  label: string;
  /** Shown under the field in the danger colour; also marks the field invalid. */
  error?: string | null;
  hint?: string;
};

/** A themed text input that highlights its border while focused. */
export function TextField({ label, error, hint, style, onFocus, onBlur, ...input }: Props) {
  const colors = useColors();
  const [focused, setFocused] = useState(false);
  const borderColor = error ? colors.danger : focused ? colors.primary : colors.border;

  return (
    <View style={styles.wrap}>
      <Text style={[styles.label, { color: colors.muted }]}>{label}</Text>
      <TextInput
        placeholderTextColor={colors.faint}
        accessibilityLabel={label}
        {...input}
        onFocus={(e) => {
          setFocused(true);
          onFocus?.(e);
        }}
        onBlur={(e) => {
          setFocused(false);
          onBlur?.(e);
        }}
        style={[
          styles.input,
          { color: colors.text, backgroundColor: colors.card, borderColor },
          focused && styles.focused,
          style,
        ]}
      />
      {error ? (
        <Text style={[styles.note, { color: colors.danger }]}>{error}</Text>
      ) : hint ? (
        <Text style={[styles.note, { color: colors.faint }]}>{hint}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: spacing.xs },
  label: { fontSize: 13, fontWeight: '700', letterSpacing: 0.3 },
  input: {
    minHeight: 52,
    borderRadius: radius.md,
    borderWidth: 1,
    paddingHorizontal: spacing.md,
    fontSize: 16,
  },
  focused: { borderWidth: 1.5 },
  note: { fontSize: 13, lineHeight: 18 },
});
