import { StyleSheet, Text, View } from 'react-native';

import { useColors } from '@/constants/theme';

type Props = {
  flag: string;
  /** Badge size; the emoji scales with it. */
  size?: number;
};

/**
 * The country flag in a soft rounded tile. Emoji flags render on Android and iOS, so no
 * image assets or network requests are needed and the badge stays crisp on every density.
 */
export function FlagBadge({ flag, size = 44 }: Props) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.tile,
        {
          width: size,
          height: size,
          borderRadius: size * 0.32,
          backgroundColor: colors.cardAlt,
          borderColor: colors.border,
        },
      ]}>
      <Text style={{ fontSize: size * 0.5 }}>{flag}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  tile: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
  },
});
