import type { ReactNode } from 'react';
import { Pressable, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { elevation, radius, spacing, useColors } from '@/constants/theme';

type Props = {
  children: ReactNode;
  /** Makes the whole card tappable (e.g. open a link). */
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  /** Adds a coloured glow behind the card, used for the active/connected state. */
  glowColor?: string;
};

/** A frosted-glass surface: translucent fill, hairline border and a soft shadow. */
export function Card({ children, onPress, style, glowColor }: Props) {
  const colors = useColors();
  const base: StyleProp<ViewStyle> = [
    styles.card,
    { backgroundColor: colors.card, borderColor: colors.border },
    glowColor
      ? {
          shadowColor: glowColor,
          shadowOpacity: 0.5,
          shadowRadius: 18,
          shadowOffset: { width: 0, height: 8 },
          elevation: 8,
        }
      : elevation.soft,
    style,
  ];
  if (!onPress) {
    return <View style={base}>{children}</View>;
  }
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [base, pressed && { opacity: 0.85, transform: [{ scale: 0.99 }] }]}>
      {children}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    padding: spacing.md,
    gap: spacing.sm,
  },
});
