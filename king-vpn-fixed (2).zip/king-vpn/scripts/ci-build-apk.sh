#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# ساخت APK اندروید روی سرور گیت‌هاب (GitHub Actions).
#
# این اسکریپت تمام کار سنگین را انجام می‌دهد تا فایل workflow کوتاه بماند و
# کپی-پیست کردنش روی گوشی راحت باشد. فایل workflow فقط این را صدا می‌زند.
#
# اجرای دستی روی کامپیوتر هم ممکن است، ولی به Android SDK و JDK 17 نیاز دارد.
# ---------------------------------------------------------------------------
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

OUT="${GITHUB_WORKSPACE:-$ROOT}/output"
mkdir -p "$OUT"

echo "==> پوشه‌ی پروژه: $ROOT"

# ۱) نصب وابستگی‌ها از lockfile (نسخه‌ها دقیقاً همان‌هایی هستند که تست شده‌اند)
if [ -f package-lock.json ]; then
  npm ci --no-audit --no-fund
else
  npm install --no-audit --no-fund
fi

# ۲) دو کتابخانه‌ی نیتیو تونل (~۶۰ مگابایت) داخل zip نیستند چون از سقف آپلود
#    گیت‌هاب بزرگ‌ترند. اینجا دانلود و با SHA-256 بررسی می‌شوند.
bash scripts/fetch-native-libs.sh

# ۴) ساخت پروژه‌ی نیتیو اندروید از روی app.json
npx expo prebuild --platform android --no-install --clean

# ۴.۵) نصب دقیقاً همان NDK ای که React Native همین نسخه پین کرده (از خود node_modules
#    خوانده می‌شود، نه عدد ثابت). ماژول تونل هم به همین نسخه پین است.
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/local/lib/android/sdk}}"
NDK_VERSION=$(grep -rhoE 'ndk(Version)?[" =:]+[0-9]+\.[0-9]+\.[0-9]{6,}' \
  node_modules/react-native/gradle/libs.versions.toml android/build.gradle 2>/dev/null \
  | grep -oE '[0-9]+\.[0-9]+\.[0-9]{6,}' | head -n 1 || true)
NDK_VERSION="${NDK_VERSION:-27.1.12297006}"
echo "==> NDK مورد نیاز: $NDK_VERSION"
if [ ! -d "$SDK_ROOT/ndk/$NDK_VERSION" ]; then
  yes | "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null 2>&1 || true
  yes | "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --install "ndk;$NDK_VERSION" || \
    echo "::warning::نصب NDK $NDK_VERSION انجام نشد؛ Gradle خودش تلاش می‌کند."
fi

# ۴.۶) دو AAR نیتیو را مستقیم به ماژول app می‌دهیم. ماژول تونل آن‌ها را فقط
#    compileOnly دارد (AGP وابستگی مستقیم .aar داخل ماژول library را قبول
#    نمی‌کند)، ولی ماژول application قبول می‌کند و آن‌ها را در APK می‌گذارد.
APP_GRADLE="android/app/build.gradle"
[ -f "$APP_GRADLE" ] || { echo "::error::android/app/build.gradle پیدا نشد."; exit 1; }
if ! grep -q 'king-vpn-native-aars' "$APP_GRADLE"; then
  cat >> "$APP_GRADLE" <<GRADLE_EOF

// king-vpn-native-aars
dependencies {
    implementation files('$ROOT/modules/king-vpn-tunnel/android/libs/libv2ray.aar')
    implementation files('$ROOT/modules/king-vpn-tunnel/android/libs/hev.aar')
}
GRADLE_EOF
fi

# ۵) حافظه‌ی Gradle (پیش‌فرض رانر برای این پروژه کم است)
PROPS="android/gradle.properties"
[ -f "$PROPS" ] || { echo "::error::prebuild فایل gradle.properties را نساخت."; exit 1; }
if grep -q '^org.gradle.jvmargs=' "$PROPS"; then
  sed -i 's|^org.gradle.jvmargs=.*|org.gradle.jvmargs=-Xmx4g -XX:MaxMetaspaceSize=1g|' "$PROPS"
else
  printf '\norg.gradle.jvmargs=-Xmx4g -XX:MaxMetaspaceSize=1g\n' >> "$PROPS"
fi

# ۶) بیلد. هیچ fallback یا || اینجا نیست تا خطای واقعی Gradle دیده شود.
cd android
chmod +x gradlew
set +e
./gradlew assembleRelease --no-daemon --stacktrace 2>&1 | tee "$OUT/gradle-build.log"
GRADLE_RC=${PIPESTATUS[0]}
set -e
if [ "$GRADLE_RC" -ne 0 ]; then
  {
    echo "### ❌ بیلد شکست خورد — علت اصلی"
    echo '```'
    grep -E -B1 -A12 "What went wrong|^e: |error: |Execution failed|FAILURE:" "$OUT/gradle-build.log" | head -n 80
    echo '```'
  } >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
  exit "$GRADLE_RC"
fi
cd "$ROOT"

# ۷) برداشتن APK
APK=$(find android/app/build/outputs/apk/release -name "*.apk" | head -n 1)
[ -n "$APK" ] || { echo "::error::هیچ APK تولید نشد."; exit 1; }
cp "$APK" "$OUT/king-vpn.apk"

# ۸) امضا. APK بدون امضا روی گوشی نصب نمی‌شود («App not installed»).
APKSIGNER=$(find "$SDK_ROOT/build-tools" -name apksigner -type f 2>/dev/null | sort -V | tail -n 1)
if [ -n "$APKSIGNER" ] && ! "$APKSIGNER" verify "$OUT/king-vpn.apk" > /dev/null 2>&1; then
  echo "==> APK امضا نشده بود؛ با keystore دیباگ امضا می‌شود."
  KS="android/app/debug.keystore"
  if [ ! -f "$KS" ]; then
    keytool -genkeypair -v -storetype PKCS12 -keystore "$KS" \
      -storepass android -alias androiddebugkey -keypass android \
      -keyalg RSA -keysize 2048 -validity 10000 \
      -dname "CN=Android Debug,O=Android,C=US"
  fi
  "$APKSIGNER" sign --ks "$KS" --ks-pass pass:android --ks-key-alias androiddebugkey \
    --key-pass pass:android --out "$OUT/signed.apk" "$OUT/king-vpn.apk"
  mv "$OUT/signed.apk" "$OUT/king-vpn.apk"
  "$APKSIGNER" verify "$OUT/king-vpn.apk"
fi

ls -lh "$OUT/king-vpn.apk"

# ۹) خلاصه‌ی فارسی در صفحه‌ی اجرا
SIZE=$(du -h "$OUT/king-vpn.apk" | cut -f1)
{
  echo "### ✅ APK آماده شد"
  echo ""
  echo "**حجم:** $SIZE"
  echo ""
  echo "از بخش **Artifacts** پایین همین صفحه یا از تب **Releases** دانلود کنید."
} >> "${GITHUB_STEP_SUMMARY:-/dev/null}"

# ۱۰) انتشار در Releases تا لینک دانلود مستقیم و قابل باز شدن روی گوشی باشد
if [ -n "${GH_TOKEN:-}" ] && command -v gh > /dev/null 2>&1; then
  TAG="apk-${GITHUB_RUN_NUMBER:-local}"
  gh release create "$TAG" "$OUT/king-vpn.apk" \
    --title "KING VPN APK (build ${GITHUB_RUN_NUMBER:-local})" \
    --notes "APK ساخته‌شده به‌صورت خودکار از سورس‌کد. فایل king-vpn.apk را دانلود و نصب کنید." \
    --latest 2>/dev/null || gh release upload "$TAG" "$OUT/king-vpn.apk" --clobber
fi

echo "==> تمام. فایل: $OUT/king-vpn.apk"
