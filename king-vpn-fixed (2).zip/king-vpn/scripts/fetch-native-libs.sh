#!/usr/bin/env bash
# Downloads the two native tunnel libraries the Android build needs.
#
# Why this exists: libv2ray.aar (~40 MB) and hev.aar (~20 MB) are too large to keep
# in the source archive, so they are not committed. Gradle links them from
# modules/king-vpn-tunnel/android/libs/, so they MUST be present before the Android
# build runs. EAS Build has no equivalent of the GitHub Actions "Fetch the native
# tunnel libraries" step, so this script is wired to the `eas-build-post-install`
# npm hook in package.json — EAS runs it after `npm install` and `expo prebuild`,
# which is exactly before Gradle starts.
#
# It is safe to run more than once: files that already match their SHA-256 are kept.
set -euo pipefail

# Resolve the project root no matter where the script is called from.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LIBS="$ROOT/modules/king-vpn-tunnel/android/libs"
mkdir -p "$LIBS"

LIBV2RAY_URL="https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.11.9/libv2ray.aar"
LIBV2RAY_SHA="cdfef146218233a31a8b52c8b1016557730d3b63fc121d4c84cacea50e669155"

HEV_URL="https://github.com/heiher/hev-socks5-tunnel/releases/download/2.20.0/hev-socks5-tunnel.aar"
HEV_SHA="ae8a2e96b80b4eccccd037805a4bb4a278090c89dbcae8bc6fcb7634e9a255b9"

sha_of() { sha256sum "$1" | awk '{print $1}'; }

fetch() {
  local name="$1" url="$2" want="$3" dest="$LIBS/$1"
  if [ -f "$dest" ] && [ "$(sha_of "$dest")" = "$want" ]; then
    echo "==> $name already present and verified."
    return 0
  fi
  echo "==> Downloading $name ..."
  curl -sSL --fail --retry 3 --retry-delay 2 -o "$dest.part" "$url"
  local got
  got="$(sha_of "$dest.part")"
  if [ "$got" != "$want" ]; then
    rm -f "$dest.part"
    echo "ERROR: $name checksum mismatch." >&2
    echo "  expected: $want" >&2
    echo "  got:      $got" >&2
    exit 1
  fi
  mv "$dest.part" "$dest"
  echo "==> $name verified."
}

fetch "libv2ray.aar" "$LIBV2RAY_URL" "$LIBV2RAY_SHA"
fetch "hev.aar"      "$HEV_URL"      "$HEV_SHA"

echo "==> Native tunnel libraries ready in $LIBS"
ls -lh "$LIBS"/*.aar
