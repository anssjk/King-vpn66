package com.kingvpn.tunnel

import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

/**
 * A minimal SOCKS5 client, used to prove a config really works.
 *
 * `testConfigAsync` starts Xray with a candidate config and then needs to send *something*
 * through it. Xray exposes a SOCKS5 inbound, so this class performs the SOCKS5 handshake
 * and an HTTP request over the resulting socket. If the response comes back with the
 * server's exit IP, the whole chain — handshake, transport, outbound — is proven to work.
 *
 * It is deliberately tiny: no authentication (the inbound is loopback-only and
 * unauthenticated), IPv4 and domain targets only, one request per connection.
 */
object SocksProbe {

  data class Result(val ok: Boolean, val ip: String?, val error: String?)

  /**
   * Open a SOCKS5 connection to `host:port` through the local proxy and fetch `path`.
   *
   * Returns the `ip=` value from Cloudflare's trace response, which is the address the
   * *server* sees — the honest proof that traffic left through the tunnel.
   */
  fun fetchThroughSocks(
    socksPort: Int,
    host: String,
    port: Int,
    path: String,
    timeoutMs: Int,
  ): Result {
    var socket: Socket? = null
    try {
      socket = Socket()
      socket.connect(InetSocketAddress("127.0.0.1", socksPort), timeoutMs)
      socket.soTimeout = timeoutMs
      val out = socket.getOutputStream()
      val input = socket.getInputStream()

      // 1. Greeting: SOCKS5, one method, "no authentication".
      out.write(byteArrayOf(0x05, 0x01, 0x00))
      out.flush()
      val greeting = readFully(input, 2)
      if (greeting[0].toInt() != 0x05 || greeting[1].toInt() != 0x00) {
        return Result(false, null, "The proxy refused the SOCKS5 handshake.")
      }

      // 2. CONNECT to the target. A literal IPv4 address is used when the host is one,
      //    otherwise the domain form so the proxy resolves it.
      val request = buildConnectRequest(host, port)
      out.write(request)
      out.flush()

      val replyHead = readFully(input, 4)
      if (replyHead[1].toInt() != 0x00) {
        return Result(false, null, "The proxy could not reach the server (code ${replyHead[1]}).")
      }
      // Consume the bound address so the stream is positioned at the payload.
      when (replyHead[3].toInt()) {
        0x01 -> readFully(input, 4 + 2)
        0x04 -> readFully(input, 16 + 2)
        0x03 -> {
          val len = readFully(input, 1)[0].toInt() and 0xFF
          readFully(input, len + 2)
        }
        else -> return Result(false, null, "The proxy sent an unknown address type.")
      }

      // 3. A real HTTP request through the tunnel.
      val http = "GET $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: KINGVPN/1.0\r\n" +
        "Accept: text/plain\r\nConnection: close\r\n\r\n"
      out.write(http.toByteArray(Charsets.US_ASCII))
      out.flush()

      val body = readBody(input)
      val ip = body.split('\n')
        .firstOrNull { it.startsWith("ip=") }
        ?.substringAfter('=')
        ?.trim()
      if (ip.isNullOrEmpty()) {
        return Result(false, null, "The server answered but reported no exit address.")
      }
      return Result(true, ip, null)
    } catch (e: Exception) {
      return Result(false, null, e.message ?: e.javaClass.simpleName)
    } finally {
      try {
        socket?.close()
      } catch (_: Exception) {
      }
    }
  }

  private fun buildConnectRequest(host: String, port: Int): ByteArray {
    val isIpv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)
    val out = java.io.ByteArrayOutputStream()
    out.write(0x05) // version
    out.write(0x01) // CONNECT
    out.write(0x00) // reserved
    if (isIpv4) {
      out.write(0x01)
      for (part in host.split('.')) out.write(part.toInt() and 0xFF)
    } else {
      out.write(0x03)
      val bytes = host.toByteArray(Charsets.US_ASCII)
      out.write(bytes.size)
      out.write(bytes)
    }
    out.write((port shr 8) and 0xFF)
    out.write(port and 0xFF)
    return out.toByteArray()
  }

  private fun readFully(input: InputStream, count: Int): ByteArray {
    val buffer = ByteArray(count)
    var read = 0
    while (read < count) {
      val n = input.read(buffer, read, count - read)
      if (n < 0) throw java.io.EOFException("The proxy closed the connection early.")
      read += n
    }
    return buffer
  }

  /** Read the HTTP response and return its body, skipping the headers. */
  private fun readBody(input: InputStream): String {
    val all = StringBuilder()
    val buffer = ByteArray(1024)
    while (all.length < 8192) {
      val n = try {
        input.read(buffer)
      } catch (_: Exception) {
        -1
      }
      if (n < 0) break
      all.append(String(buffer, 0, n, Charsets.UTF_8))
    }
    val text = all.toString()
    val split = text.indexOf("\r\n\r\n")
    return if (split >= 0) text.substring(split + 4) else text
  }
}
