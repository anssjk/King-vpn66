package com.kingvpn.tunnel

import android.content.Context
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.io.File

/**
 * The Xray-core engine.
 *
 * This is the multi-protocol half of the tunnel. Xray-core is the same core the popular
 * Android clients use, and it is what actually speaks VLESS, VMess, Trojan and
 * Shadowsocks over TCP, WebSocket, gRPC, XHTTP, TLS and REALITY. It is linked in as a
 * JNI library (`libv2ray.aar`), so the protocol work happens in native code and this
 * class only owns its lifecycle.
 *
 * ## How it fits together
 *
 * Xray does **not** own the TUN interface here. It is started with a SOCKS5 inbound on
 * `127.0.0.1`, and `HevTunnel` bridges the VpnService TUN to that port. That split is
 * deliberate: it keeps the packet-level work (TUN) and the protocol-level work (Xray)
 * in the two libraries that each do it best, and it means the outbound is a plain Xray
 * JSON config that can be built and unit-tested in JavaScript.
 *
 * `startLoop(config, 0)` is called with a TUN fd of `0`, which tells the core "do not
 * create a TUN" — the VpnService already did.
 */
object XrayEngine {

  @Volatile
  private var controller: CoreController? = null

  @Volatile
  private var running = false

  /** The last failure, for the UI to show instead of a silent no-op. */
  @Volatile
  var lastError: String? = null

  /** The core's own version string, e.g. `Lib v40, Xray-core v26.11.9`. */
  @Volatile
  var version: String = ""

  /**
   * Prepare the core's environment once per process.
   *
   * `initCoreEnv` points the core at the app's files directory and installs a file reader
   * that falls back to the APK's assets. That fallback is what lets `geoip.dat` and
   * `geosite.dat` — which ship inside the AAR and are merged into the app's assets — be
   * found without copying them out first.
   */
  fun init(context: Context) {
    if (version.isNotEmpty()) return
    try {
      Libv2ray.initCoreEnv(context.filesDir.absolutePath, "")
      version = Libv2ray.checkVersionX()
    } catch (e: Throwable) {
      lastError = e.message ?: e.javaClass.simpleName
    }
  }

  /**
   * Start the core with a full Xray JSON config.
   *
   * The config is written to a file as well as passed in memory, so a support report can
   * show exactly what the core was asked to do. Returns false (with `lastError` set)
   * rather than throwing, so the caller can surface the real reason.
   */
  fun start(context: Context, configJson: String): Boolean {
    init(context)
    if (running) return true

    try {
      File(context.filesDir, "xray-config.json").writeText(configJson)
    } catch (e: Throwable) {
      lastError = "Could not write the core config: ${e.message}"
      return false
    }

    val handler = object : CoreCallbackHandler {
      override fun onEmitStatus(l: Long, s: String?): Long = 0
      override fun shutdown(): Long {
        running = false
        return 0
      }

      override fun startup(): Long {
        running = true
        return 0
      }
    }

    val created = try {
      Libv2ray.newCoreController(handler)
    } catch (e: Throwable) {
      lastError = "Could not create the core: ${e.message}"
      return false
    }
    controller = created

    return try {
      // 0 = no TUN: the VpnService owns the interface and hev bridges it to our SOCKS port.
      created.startLoop(configJson, 0)
      running = true
      lastError = null
      true
    } catch (e: Throwable) {
      lastError = e.message ?: e.javaClass.simpleName
      running = false
      try {
        created.stopLoop()
      } catch (_: Throwable) {
      }
      controller = null
      false
    }
  }

  /** Stop the core. Safe to call when it is already stopped. */
  fun stop() {
    val c = controller
    controller = null
    running = false
    if (c == null) return
    try {
      c.stopLoop()
    } catch (_: Throwable) {
      // Already down.
    }
  }

  fun isRunning(): Boolean = running
}
