package com.kingvpn.tunnel

import android.content.Context
import java.io.File

/**
 * The TUN-to-SOCKS5 bridge.
 *
 * `hev-socks5-tunnel` reads raw IP packets from the VpnService TUN file descriptor and
 * forwards them to a SOCKS5 server — here, the Xray core's local SOCKS inbound. This is
 * the piece that turns "Xray is running" into "the phone's traffic actually goes through
 * the proxy": without it the core would be listening on a port nothing feeds.
 *
 * The library is driven entirely through a YAML config file plus the TUN fd, so this
 * class only writes that file and calls the three native entry points.
 */
object HevTunnel {

  /** The local SOCKS5 port Xray listens on. Loopback only — never exposed. */
  const val SOCKS_PORT = 1080

  /** The TUN interface address the VpnService assigns. */
  const val TUN_ADDRESS = "198.18.0.1"

  @Volatile
  var lastError: String? = null

  /**
   * Build the YAML config the bridge reads.
   *
   * `mtu` matches the VpnService's own MTU so the two agree on packet size. `udp: 'udp'`
   * keeps DNS and QUIC working (a TCP-only relay would silently break name resolution).
   * `log-level: warn` keeps the log quiet in normal use but still records real problems.
   */
  private fun buildConfig(mtu: Int): String = """
    tunnel:
      name: tun0
      mtu: $mtu
      multi-queue: false
      ipv4: $TUN_ADDRESS
      icmp: 'off'

    socks5:
      port: $SOCKS_PORT
      address: 127.0.0.1
      udp: 'udp'

    misc:
      log-level: warn
      connect-timeout: 10000
      tcp-read-write-timeout: 300000
      udp-read-write-timeout: 60000
  """.trimIndent()

  /**
   * The native entry points are looked up by reflection on purpose.
   *
   * Upstream hev-socks5-tunnel declares `TProxyStartService(String, int)` and
   * `TProxyStopService()` as `void`, and has no `TProxyIsRunning()`. Calling them
   * directly (and using the result as a Boolean) fails to compile against that API.
   * Reflection makes the build independent of the exact AAR signature: a missing method
   * becomes a readable runtime error instead of a Kotlin compile error.
   */
  private val candidates = listOf("hev.htproxy.TProxyService", "com.v2ray.ang.service.TProxyService")

  private fun service(): Class<*>? {
    for (name in candidates) {
      try {
        return Class.forName(name)
      } catch (_: Throwable) {
      }
    }
    return null
  }

  @Volatile
  private var started = false

  fun start(context: Context, tunFd: Int, mtu: Int): Boolean {
    if (started) return true
    return try {
      val cls = service() ?: run {
        lastError = "The TUN bridge library (hev) is not in the app."
        return false
      }
      val file = File(context.filesDir, "hev-socks5-tunnel.yml")
      file.writeText(buildConfig(mtu))
      val m = cls.getMethod("TProxyStartService", String::class.java, Int::class.javaPrimitiveType)
      val result = m.invoke(null, file.absolutePath, tunFd)
      // `void` returns null; a Boolean return of false means the library refused.
      if (result is Boolean && !result) {
        lastError = "The TUN bridge refused to start."
        false
      } else {
        started = true
        lastError = null
        true
      }
    } catch (e: Throwable) {
      lastError = (e.cause ?: e).let { it.message ?: it.javaClass.simpleName }
      false
    }
  }

  /** Stop the bridge. Safe to call when it is already stopped. */
  fun stop() {
    try {
      if (started) {
        service()?.getMethod("TProxyStopService")?.invoke(null)
      }
    } catch (_: Throwable) {
      // Already down.
    } finally {
      started = false
    }
  }

  fun isRunning(): Boolean = started

  /**
   * Real traffic counters from the bridge: `[txPackets, txBytes, rxPackets, rxBytes]`.
   * These only move when packets actually cross the tunnel.
   */
  fun stats(): LongArray = try {
    if (!started) LongArray(4)
    else (service()?.getMethod("TProxyGetStats")?.invoke(null) as? LongArray) ?: LongArray(4)
  } catch (_: Throwable) {
    LongArray(4)
  }
}
