# Native tunnel libraries

This folder holds the two native libraries the tunnel needs. They are **not** in the
source zip, because together they are about 60 MB — larger than GitHub's 25 MB
browser-upload limit — and a binary that size does not belong in a source archive.

The build workflow (`.github/workflows/build-apk.yml`) downloads them from their official
release pages and verifies each one against a recorded SHA-256 before the build starts, so
a build can never silently pick up a different binary.

| File | What it is | Version | SHA-256 |
|---|---|---|---|
| `libv2ray.aar` | Xray-core, built for Android (JNI). The multi-protocol core: VLESS, VMess, Trojan, Shadowsocks over TCP, WebSocket, gRPC, XHTTP, TLS and REALITY. | `v26.11.9` | `cdfef146218233a31a8b52c8b1016557730d3b63fc121d4c84cacea50e669155` |
| `hev.aar` | `hev-socks5-tunnel` — the TUN-to-SOCKS5 bridge that carries the device's packets to the core's local SOCKS port. | `2.20.0` | `ae8a2e96b80b4eccccd037805a4bb4a278090c89dbcae8bc6fcb7634e9a255b9` |

## Getting them by hand

If you are building locally rather than through the workflow, download them into this
folder with these exact names:

```bash
curl -sSL -o libv2ray.aar \
  https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.11.9/libv2ray.aar

curl -sSL -o hev.aar \
  https://github.com/heiher/hev-socks5-tunnel/releases/download/2.20.0/hev-socks5-tunnel.aar
```

Then check them:

```bash
sha256sum libv2ray.aar hev.aar
```

The two hashes must match the table above. If they do not, the download is not the build
this source was written against — do not build with it.

## Why these two

- **Xray-core** is the core the widely used Android clients are built on, and it is the
  one that actually implements the protocols and transports this app offers. It is linked
  in as a JNI library, so the protocol work happens in native code.
- **hev-socks5-tunnel** is the piece that turns "the core is running" into "the phone's
  traffic goes through the proxy". Xray exposes a SOCKS5 inbound; this library reads the
  raw IP packets from the `VpnService` TUN file descriptor and hands them to that port.
  Without it the core would be listening on a port nothing feeds.
